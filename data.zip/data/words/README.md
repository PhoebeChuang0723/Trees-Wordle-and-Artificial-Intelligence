# Word files description

- official_wordle.txt: list of all words that were correct answers in Wordle, plus the word "sepal" (retrieved: https://gist.github.com/cfreshman/a03ef2cba789d8cf00c08f767e0fad7b)
- official_wordle_guesses.txt: list of all words that are considered valid guesses in Wordle (retrieved: https://gist.github.com/cfreshman/cdcdf777450c5b5301e439061d29694c)
- possible_words_four.txt: list of possible four-letter words (retrieved: https://gist.github.com/paulcc/3799331)

All other word files are subsets of official_wordle.txt.
